"use client"

import { useEffect, useState, type ReactNode, type ElementType } from "react"
import { BrandWordmark } from "./brand-wordmark"

/** Connect landing header, including its separate wordmark and glass collapse thresholds. */
export function HomeHeader({ actions, brandHref = "/", LinkComponent = "a" }: {
  actions: ReactNode; brandHref?: string; LinkComponent?: ElementType
}) {
  const [brandCollapsed, setBrandCollapsed] = useState(false)
  const [headerCollapsed, setHeaderCollapsed] = useState(false)
  useEffect(() => {
    let frame = 0
    function update() {
      frame = 0
      setBrandCollapsed(current => window.scrollY > 80 ? true : window.scrollY < 20 ? false : current)
      setHeaderCollapsed(current => window.scrollY > 320 ? true : window.scrollY < 260 ? false : current)
    }
    function schedule() { if (!frame) frame = window.requestAnimationFrame(update) }
    update()
    window.addEventListener("scroll", schedule, { passive: true })
    window.addEventListener("resize", schedule)
    window.addEventListener("hashchange", schedule)
    return () => {
      window.removeEventListener("scroll", schedule)
      window.removeEventListener("resize", schedule)
      window.removeEventListener("hashchange", schedule)
      window.cancelAnimationFrame(frame)
    }
  }, [])
  return <header className="home-header" data-collapsed={headerCollapsed}>
    <div className="home-container home-header-inner">
      <BrandWordmark href={brandHref} collapsed={brandCollapsed} LinkComponent={LinkComponent} />
      <div className="home-header-actions">{actions}</div>
    </div>
  </header>
}
