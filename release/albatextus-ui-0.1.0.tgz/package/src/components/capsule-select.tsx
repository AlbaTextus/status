"use client"

import { useId } from "react"
import { Toggle } from "@base-ui/react/toggle"
import { ToggleGroup } from "@base-ui/react/toggle-group"
import { LayoutGroup, motion, useReducedMotion } from "framer-motion"
import type { LucideIcon } from "lucide-react"
import { cn } from "cn"
import { InteractionCaption, useInteractionCaption } from "./interaction-caption"

export type CapsuleOption<Value extends string = string> = {
  value: Value; label: string; icon: LucideIcon; disabled?: boolean
}
export type CapsuleSelectProps<Value extends string = string> = {
  options: readonly CapsuleOption<Value>[]
  value: Value
  onValueChange: (value: Value) => void
  label: string
  disabled?: boolean
  className?: string
}

export function CapsuleSelect<Value extends string>({ options, value, onValueChange, label, disabled, className }: CapsuleSelectProps<Value>) {
  const id = useId()
  const caption = useInteractionCaption()
  const reducedMotion = Boolean(useReducedMotion())
  return <div className={cn("capsule-select", className)} onKeyDown={event => { if (event.key === "Escape") caption.dismiss() }}>
    <LayoutGroup id={id}>
      <ToggleGroup aria-label={label} className="capsule-select-track" value={[value]} disabled={disabled}
        onValueChange={values => { if (values.length) onValueChange(values[0]) }}>
        {options.map(({ value: optionValue, label: optionLabel, icon: Icon, disabled: optionDisabled }) =>
          <Toggle key={optionValue} value={optionValue} disabled={optionDisabled} aria-label={optionLabel}
            className="capsule-select-option" {...caption.bind(optionLabel)}>
            {value === optionValue && <motion.span className="capsule-select-highlight" aria-hidden="true"
              layoutId={reducedMotion ? undefined : "capsule-selection"}
              transition={{ duration: reducedMotion ? 0 : 0.32, ease: [0.22, 1, 0.36, 1] }} />}
            <Icon aria-hidden="true" strokeWidth={1.8} />
          </Toggle>)}
      </ToggleGroup>
    </LayoutGroup>
    <InteractionCaption title={disabled ? null : caption.title} />
  </div>
}
