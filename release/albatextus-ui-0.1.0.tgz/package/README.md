# ALBATEXTUS UI

专属 React 组件库，导航来自 Connect，页脚采用 athub 新设计。保留原版导航动画、提示框，以及页脚蓝粉流动渐变、颗粒纹理和响应式布局。

## 本地展示

```sh
npm ci
npm run dev
```

打开 http://127.0.0.1:3300。展示页提供组件切换、移动端预览、明暗主题及代码复制。预览中的用户中心导航切换演示状态，不连接账户后端；导航右侧内容由 `actions` 传入。

## 安装到项目

```sh
npm run pack:release
# 在使用组件的项目中执行，路径按实际位置调整
npm install ../ui/release/albatextus-ui-0.1.0.tgz
```

本包交付 TypeScript 源码，需要 React 19、支持 TSX 的构建器及 Tailwind CSS v4 PostCSS 插件。Next.js 配置添加 `transpilePackages: ["@albatextus/ui"]`。全局入口引入样式一次；样式包含 Connect 的全局主题、基础重置与字体设定，适用于使用同一设计系统的应用。

```tsx
import { House, UserRound } from "lucide-react"
import { SiteHeader, SiteFooter, ThemeProvider, ThemeToggle } from "@albatextus/ui"
import "@albatextus/ui/styles.css"

const navigation = [
  { href: "/account", title: "用户中心", icon: House },
  { href: "/account/profile", title: "个人资料", icon: UserRound },
]

export function App() {
  return <ThemeProvider>
    <SiteHeader items={navigation} activeHref="/account" routeKey="/account"
      navigationLabel="用户中心导航" actions={<ThemeToggle />} />
    <main>页面内容</main>
    <SiteFooter />
  </ThemeProvider>
}
```

## 组件 API

交互约定见 [DESIGN.md](./DESIGN.md)：图标优先；说明只在悬浮或键盘聚焦时出现。

| 组件 | 配置 |
| --- | --- |
| `SiteHeader` | `items`、`activeHref`、`navigationLabel`、`routeKey`、`actions`、`brandHref`、`LinkComponent`、`BrandLinkComponent` |
| `HomeHeader` | `actions`、`brandHref`、`LinkComponent` |
| `SiteFooter` | `brandHref`、`wikiOrigin`、`LinkComponent` |
| `BrandCard` | 独立的 ALBATEXTUS 蓝粉流动品牌卡片，无必填属性 |
| `BrandWordmark` | `footer`、`collapsed`、`href`、`LinkComponent` |
| `ThemeProvider` | `children`；使用 `.dark` 与 `albatextus-color-mode` 存储键，默认浅色 |
| `ThemeToggle` | 与 Connect 相同的主题切换按钮 |
| `Button` | 原版 Base UI 按钮，支持 `variant`、`size`、`render` |
| `IconButton` | 必填 `label`，图标作为 `children`；支持 Button 的操作与变体属性；自动提供 Tooltip 和可访问名称 |
| `CapsuleSelect` | `label`、`options`（`value` / `label` / `icon` / `disabled`）、`value`、`onValueChange`、`disabled`、`className`；受控单选 |

```tsx
<IconButton label="复制代码" onClick={copy}><Copy aria-hidden="true" /></IconButton>
<CapsuleSelect label="选择视图" value={view} onValueChange={setView}
  options={[
    { value: "grid", label: "网格视图", icon: Grid2X2 },
    { value: "list", label: "列表视图", icon: List },
  ]} />
```

导航栏与胶囊选择器共用下方文字提示规则：只响应悬浮或键盘聚焦，移开／失焦后收起，Escape 关闭；选中和路由变化不再自动显示 5 秒文字。胶囊支持方向键切换焦点，空格选择，重复点击选中项不会清空选择。

`LinkComponent` 默认普通 `a`，Next.js 可传入 `next/link`。`SiteHeader` 会给自定义路由组件传 `prefetch`，适配器应按需处理。`routeKey` 应与实际路由同步。

`SiteFooter` 默认展示 athub 新版页脚：品牌字标、社区项目图标及 `BrandCard`，不再默认链接到本地 Wiki。需要版权和法律信息时，传入 `wikiOrigin="https://your-wiki.example"`；它们显示在品牌卡片上方。`wikiOrigin=""` 使用当前站点的 `/privacy` 和 `/terms`。品牌卡片的动画遵循系统“减少动态效果”偏好。

## 来源与一致性

- `SiteHeader`、`BrandWordmark`、`ThemeProvider` 与原版基础组件来源于 `connect/web/components/`。导航栏提示行为按本库的新图标规则调整，其余布局和滚动动效保留。
- `HomeHeader` 提取自 `home-page.tsx`，保留字标 80/20px、导航 320/260px 的双阈值滚动逻辑，业务按钮以 `actions` 注入。
- `SiteFooter` 和 `BrandCard` 来源于 athub 新版页脚，保留布局、文字、图标、蓝粉流动渐变及颗粒纹理；首页链接可配置，法律信息按需显示。
- `src/styles/connect.css` 提取自 `connect/web/styles/site.css`，并包含 `connect/web/app/globals.css` 中页脚品牌名的专用规则。保留相关规则原始顺序及声明，包括移动端和深色覆盖。没有将账户业务样式全部打包。
- 展示页样式独立于组件样式，消费包不会包含展示页。
- athub 页脚已引用本包；其他业务项目可通过更新安装包接入。

```sh
npm run typecheck
npm run build
npm run start
npm run pack:release
```

构建和安装包位于 `release/`，本地验证脚本与截图位于 `temp/`，两者均不提交 Git。
